package com.mphasis.data.producer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PNRModel {

	private String model;
	private String createDateTime;
	private String bookingReferenceID;
	private String lastModified;
	private String flightSegment_RPH;
	private String flightSegment_Status;
	private String flightSegment_DepartureDay;
	private String numberInParty;
	private String marketingAirline;
	private String departureAirport;
	private String arrivalAirport;
	private String departureDateTime;
	private String arrivalDateTime;
	private String resBookDesigCode;
	private String seatNumber;
	private String flightNumber;
	private String surnameRefNumber;
	private String surname;
	private String surnamePrefix;
	private String travelerRefNumber_RPH;
	private String givenName;
	private String phoneUseType;
	private String locationCode;
	private String areaCityCode;
	private String phoneNumber;
	private String remark;
	private String email;
	private String custLoyalty_ProgramID;
	private String membershipID;
	private String ticketingStatus;
	private String ticketAdvisory;
	private String ssrCode;
	private String birthDate;
	private String bookingReferenceID_Context;
	private String bookingReferenceID_ID;
	private String pnr_type_code;
	private String passengerTypeCode;

	public void parseModel(String[] params) {
		model = params[0];
		createDateTime = params[1];
		bookingReferenceID = params[2];
		lastModified = params[3];
		flightSegment_RPH = params[4];
		flightSegment_Status = params[5];
		flightSegment_DepartureDay = params[6];
		numberInParty = params[7];
		marketingAirline = params[8];
		departureAirport = params[9];
		arrivalAirport = params[10];
		departureDateTime = params[11];
		arrivalDateTime = params[12];
		resBookDesigCode = params[13];
		seatNumber = params[14];
		flightNumber = params[15];
		surnameRefNumber = params[16];
		surname = params[17];
		surnamePrefix = params[18];
		travelerRefNumber_RPH = params[19];
		givenName = params[20];
		phoneUseType = params[21];
		locationCode = params[22];
		areaCityCode = params[23];
		phoneNumber = params[24];
		remark = params[25];
		email = params[26];
		custLoyalty_ProgramID = params[27];
		membershipID = params[28];
		ticketingStatus = params[29];
		ticketAdvisory = params[30];
		ssrCode = params[31];
		birthDate = params[32];
		bookingReferenceID_Context = params[33];
		bookingReferenceID_ID = params[34];
		pnr_type_code = params[35];
		passengerTypeCode = params[36];
	}

}

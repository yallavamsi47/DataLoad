package com.mphasis.data.producer;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class TestCSV {

	public static void read(String csvFile) throws FileNotFoundException, IOException {

		Pattern pattern = Pattern.compile(",");
		try (BufferedReader in = new BufferedReader(new FileReader(csvFile));) {
//			Map<String, List<PNRModel>> grouped = in.lines().skip(1).map(line -> {
//				String[] arr = pattern.split(line);
//				return new PNRModel(arr[0], arr[1], arr[2], arr[3], arr[4],arr[5],arr[6],arr[7],arr[8],arr[9],arr[10],arr[11],arr[12],arr[13],arr[14],arr[15],arr[16],arr[17],arr[18],arr[19],arr[20],arr[21],arr[22],arr[23],arr[24],arr[25],arr[26],arr[27],arr[28],arr[29],arr[30],arr[31],arr[32],arr[33],arr[34],arr[35],arr[36]);
//			}).collect(Collectors.groupingBy(x->x.getBookingReferenceID()));
//			grouped
//	        .entrySet()
//	        .stream()
//	        .forEach(System.out::println);

			List<PNRModel> pnrModel = in.lines().skip(1).map(line -> {
				String[] arr = pattern.split(line);
				return new PNRModel(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7], arr[8], arr[9],
						arr[10], arr[11], arr[12], arr[13], arr[14], arr[15], arr[16], arr[17], arr[18], arr[19],
						arr[20], arr[21], arr[22], arr[23], arr[24], arr[25], arr[26], arr[27], arr[28], arr[29],
						arr[30], arr[31], arr[32], arr[33], arr[34], arr[35], arr[36]);
			}).collect(Collectors.toList());

			System.out.println("  pnrModel  : : " + pnrModel.size());

			Map<String, String> result1 =

					pnrModel.stream().collect(

							Collectors.groupingBy(PNRModel::getBookingReferenceID,

									Collectors.mapping(PNRModel::toString, Collectors.joining("||")))

					);

//			 Map<String, List<PNRModel>> result =pnrModel.stream().collect(Collectors.groupingBy(PNRModel::getBookingReferenceID));

//			 Map<String, String> pnrmodelGroup=new HashMap<String, String>();			 			 
//			 for (String pnrbookingId : result.keySet()) {
//					if(!pnrmodelGroup.containsKey(pnrbookingId)) {
//						StringBuilder sb=new StringBuilder();
//						for(PNRModel pnr:result.get(pnrbookingId)) {
//							sb.append(pnr.toString()).append("||");
//						}
//						pnrmodelGroup.put(pnrbookingId, sb.toString());
//					}
//				}

//			 Map<String, String> pnrmodelGroup=new HashMap<String, String>();
//			 
//			 for (PNRModel pnr_Model : pnrModel) {
////				 StringBuilder sb = null;
//				 if(!pnrmodelGroup.containsKey(pnr_Model.getBookingReferenceID())) {
////					 sb=new StringBuilder();			 
////						sb.append(pnr_Model.toString()).append("||");					
//						pnrmodelGroup.put(pnr_Model.getBookingReferenceID(),pnr_Model.toString());
//				 }else {				 
//					 pnrmodelGroup.put(pnr_Model.getBookingReferenceID(),(pnrmodelGroup.get(pnr_Model.getBookingReferenceID())).concat("||").concat(pnr_Model.toString()));
//				 }
//			 } 
//			 System.out.println(pnrmodelGroup);

			for (String pnr_Group : result1.values()) {

				System.out.println(" ####################################################### " + pnr_Group);

			}

		}

	}

	public static void main(String[] args) {
		// csv file to read
		String csvFile = "C:\\STSWorkspace\\JavaSample\\Data_Producer\\PNR_DATA1.csv";
		try {
			TestCSV.read(csvFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

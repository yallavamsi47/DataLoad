package com.mphasis.data.producer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesis.model.PutRecordsRequest;
import com.amazonaws.services.kinesis.model.PutRecordsRequestEntry;
import com.amazonaws.services.kinesis.model.PutRecordsResult;
import com.amazonaws.services.kinesis.model.PutRecordsResultEntry;
import com.mphasis.data.producer.model.ConfigInfo;

public class Data_ProducerMainApp {

	static final String TASK_PROPERTIES = "Configuration.csv";
	static final int batchSize = 500;
	static long startTime = System.currentTimeMillis();
	static int recounrdCount = 0;
	static int failedCount = 0;

	public static void main(String[] args) {

//		File file = new File("src/main/resources/");
//		String absolutePath = file.getAbsolutePath();
//		System.out.println("   absolutePath   "+file.length());
//		System.out.println("   absolutePath   "+absolutePath);

//		String workingDir = args[1];
		File curDir = new File(".");
		getAllFiles(curDir);
		transferFile(args[0], "");

		long endTime = System.currentTimeMillis();
		long duration = (endTime - startTime); // Total execution time in milli seconds

		System.out.println(" Total Records Count Sent to Kinesis ######### " + recounrdCount);

		System.out.println(" Total Failed Records Count while sending data to Kinesis ######### " + failedCount);

		long seconds = (duration / 1000) % 60;

		System.out.println(" Total time taken to send the data to Kinesis in seconds ######### " + seconds);

	}

	private static void transferFile(String taskName, String workingDir) {

		List<ConfigInfo> list = readFileInfo(taskName, workingDir);

		for (ConfigInfo config : list) {
			
			if (taskName.equalsIgnoreCase(config.getJobName())) {
				AmazonKinesis kinesisClient = getKinesisClient(config);
				Path file = Paths.get(config.getLocalDirectory());
//				Properties prop=getProperties();
				

				try {
					BufferedReader bfr = Files.newBufferedReader(file);
					List<String> batch = new ArrayList<String>(batchSize);
					for (String line; (line = bfr.readLine()) != null;) {
						System.out.println("  Line : : "+line);
						batch.add(line);

						if (batch.size() == batchSize) {
//							processMessage(batch, kinesisClient, config);
							batch = new ArrayList<String>(batchSize);
						}
					}
					if (!batch.isEmpty()) {

//						processMessage(batch, kinesisClient, config);
					}
				} catch (IOException e) {

					e.printStackTrace();
				}

				
				
			}
		}

	}

	private static List<ConfigInfo> readFileInfo(String taskName, String workingDir) {

		ArrayList<ConfigInfo> list = new ArrayList<ConfigInfo>();
		try {

			String taskPath = workingDir + TASK_PROPERTIES;

			InputStream input = new FileInputStream(taskPath);
			Path file = Paths.get(taskPath);
			BufferedReader reader = Files.newBufferedReader(file);

			String line = "";
			while ((line = reader.readLine()) != null) {
				// Ignore comment and spaces

				if ("".equals(line.trim()) || line.startsWith("#")) {
					continue;
				}
				// CSV File
				String[] params = line.split(",");

				if (params.length != 6) {
					System.err.println("Warning Incorrect record: Configuration file "
							+ "CSV does not have all the fields seperated by Comma , Expecting at least 5 fields found "
							+ params.length + "\n:" + line);
					continue;
				}
				ConfigInfo info = new ConfigInfo();
				info.parse(params);
				if (taskName.equalsIgnoreCase(info.getJobName())) {
					list.add(info);
				}
			}
			reader.close();
		} catch (Exception e) {
			System.err.println("Error While Reading Configuration Error:" + e.getMessage());
		}
		return list;

	}

	private static void processMessage(List<String> batch, AmazonKinesis kinesisClient, ConfigInfo config) {

		batch.remove(0);

		PutRecordsRequest putRecordsRequest = new PutRecordsRequest();
		putRecordsRequest.setStreamName(config.getStreamName());
		List<PutRecordsRequestEntry> putRecordsRequestEntryList = new ArrayList<PutRecordsRequestEntry>();

		for (int i = 0; i < batch.size(); i++) {
			PutRecordsRequestEntry putRecordsRequestEntry = new PutRecordsRequestEntry();
			putRecordsRequestEntry.setData(ByteBuffer.wrap(String.valueOf(batch.get(i)).getBytes()));
			putRecordsRequestEntry.setPartitionKey(String.format("partitionKey-%d", i));
			putRecordsRequestEntryList.add(putRecordsRequestEntry);
		}

		putRecordsRequest.setRecords(putRecordsRequestEntryList);
		PutRecordsResult putRecordsResult = kinesisClient.putRecords(putRecordsRequest);

//		System.out.println("Response from Kinesis Put Result ---------------- > " + putRecordsResult.getRecords().size()
//				+ "<--------- FailedRecordCount ------->" + putRecordsResult.getFailedRecordCount());
		recounrdCount = recounrdCount + putRecordsResult.getRecords().size();
//		System.out.println("  recounrdCount  ---------- "+recounrdCount);
		failedCount = failedCount + putRecordsResult.getFailedRecordCount();
//		System.out.println("  failedCount  ---------- "+failedCount);

		// If Exception Occurs
		while (putRecordsResult.getFailedRecordCount() > 0) {
			final List<PutRecordsRequestEntry> failedRecordsList = new ArrayList<PutRecordsRequestEntry>();
			final List<PutRecordsResultEntry> putRecordsResultEntryList = putRecordsResult.getRecords();
			for (int i = 0; i < putRecordsResultEntryList.size(); i++) {
				final PutRecordsRequestEntry putRecordRequestEntry = putRecordsRequestEntryList.get(i);
				final PutRecordsResultEntry putRecordsResultEntry = putRecordsResultEntryList.get(i);
				if (putRecordsResultEntry.getErrorCode() != null) {
					failedRecordsList.add(putRecordRequestEntry);
				}
			}
			putRecordsRequestEntryList = failedRecordsList;
			putRecordsRequest.setRecords(putRecordsRequestEntryList);
			putRecordsResult = kinesisClient.putRecords(putRecordsRequest);
		}
//	        kinesisClient.shutdown();

	}

	public static AmazonKinesis getKinesisClient(ConfigInfo configInfo) {

		AmazonKinesisClientBuilder clientBuilder = AmazonKinesisClientBuilder.standard();
		final AWSCredentials reqCredentials = new BasicAWSCredentials(configInfo.getAwsAccessKeyId(),
				configInfo.getAwsSecretAccessKey());
		AWSStaticCredentialsProvider cp = new AWSStaticCredentialsProvider(reqCredentials);
		ClientConfiguration config = new ClientConfiguration();
		clientBuilder.setRegion(configInfo.getAwsregion());
		clientBuilder.setCredentials(cp);
		clientBuilder.setClientConfiguration(config);
		AmazonKinesis kinesisClient = clientBuilder.build();

		return kinesisClient;
	}

	private static void getAllFiles(File curDir) {

		File[] filesList = curDir.listFiles();
		for (File f : filesList) {
			if (f.isDirectory())
				System.out.println(f.getName());
				if (f.isFile()) {
				System.out.println(f.getName());
				}
		}

	}

}

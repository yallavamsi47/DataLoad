package com.mphasis.data.producer.model;

public class ConfigInfo {
	
	private String awsAccessKeyId;
	private String awsSecretAccessKey;
	private String awsregion;
	private String streamName;
	private String jobName;
	private String localDirectory;
	
	public ConfigInfo() {
		super();
	}
	public ConfigInfo(String awsAccessKeyId, String awsSecretAccessKey, String awsregion, String streamName,
			String jobName) {
		super();
		this.awsAccessKeyId = awsAccessKeyId;
		this.awsSecretAccessKey = awsSecretAccessKey;
		this.awsregion = awsregion;
		this.streamName = streamName;
		this.jobName = jobName;
		this.localDirectory=localDirectory;
	}
	
	public void parse(String []params){
		jobName	=	params[0];
		streamName	=	params[4];
		awsAccessKeyId	=	params[1];
		awsSecretAccessKey	=	params[2];
		awsregion	=	params[3];
		localDirectory	=	params[5];
	}
	
	public String getAwsAccessKeyId() {
		return awsAccessKeyId;
	}
	public void setAwsAccessKeyId(String awsAccessKeyId) {
		this.awsAccessKeyId = awsAccessKeyId;
	}
	public String getAwsSecretAccessKey() {
		return awsSecretAccessKey;
	}
	public void setAwsSecretAccessKey(String awsSecretAccessKey) {
		this.awsSecretAccessKey = awsSecretAccessKey;
	}
	public String getAwsregion() {
		return awsregion;
	}
	public void setAwsregion(String awsregion) {
		this.awsregion = awsregion;
	}
	public String getStreamName() {
		return streamName;
	}
	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getLocalDirectory() {
		return localDirectory;
	}
	public void setLocalDirectory(String localDirectory) {
		this.localDirectory = localDirectory;
	}
	@Override
	public String toString() {
		return "ConfigInfo [awsAccessKeyId=" + awsAccessKeyId + ", awsSecretAccessKey=" + awsSecretAccessKey
				+ ", awsregion=" + awsregion + ", streamName=" + streamName + ", jobName=" + jobName
				+ ", localDirectory=" + localDirectory + "]";
	}
	
}
